# RJNX Gaming

Full-stack gaming tournament platform.

## Structure

- `frontend/` — React frontend
- `backend/` — Node.js/Express/MongoDB API

## Backend setup

```bash
cd backend
npm install express mongoose cors dotenv bcryptjs jsonwebtoken socket.io
node server.js
```

Create a `.env` file:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/rjnx-gaming
JWT_SECRET=change-this-secret
```

## Frontend setup

This source tree is intended for a React/Vite application. Install the required packages:

```bash
npm install react react-dom react-router-dom axios socket.io-client
```

Set:

```env
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```
